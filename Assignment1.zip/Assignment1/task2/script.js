function goLogin() {
    const changes = document.getElementById("contain");

    changes.style.right = "-75vw";
}

function goRegister() {
    const changes = document.getElementById("contain");

    changes.style.right = "25vw";
}